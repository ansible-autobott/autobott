/**
 * This stub is used when MobileFrontend is not installed.
 * It describes the contract between MobileFrontend and Minerva
 * that we should work towards removing.
 */
module.exports = {
	stub: true
};
