# MobileFrontend JavaScript API documentation

The MobileFrontend extension helps improve the mobile presence of a MediaWiki instance. It has a limited JavaScript public API which is described by this document.
